# from django.db import models

# class User(models.Model):
#     # فیلدها

#     @staticmethod
#     def get_or_create_user(phone):
#         return User.objects.get_or_create(username=phone)