# myapp/models.py
from django.db import models

import sys
class Item(models.Model):  # Should be SINGULAR: Item, not Items
    name = models.CharField(max_length=100)
    email = models.EmailField()
    age = models.IntegerField()
    
    def __str__(self):
        return self.name

    
# from django.db import models
# from django.utils import timezone
# from datetime import timedelta

# class OTPRecord(models.Model):
#     phone_number = models.CharField(max_length=15)
#     otp = models.CharField(max_length=6)
#     created_at = models.DateTimeField(auto_now_add=True)
#     expires_at = models.DateTimeField()

#     def save(self, *args, **kwargs):
#         # Set expiration to 5 minutes from creation
#         if not self.expires_at:
#             self.expires_at = timezone.now() + timedelta(minutes=5)
#         super().save(*args, **kwargs)

#     def is_expired(self):
#         return timezone.now() > self.expires_at

    

# class ChatMessage(models.Model):
#     message = models.TextField()
#     timestamp = models.DateTimeField(auto_now_add=True)
    
# class User(models.Model):
#     url = models.URLField()
#     username = models.CharField(max_length=150, unique=True)
#     email = models.EmailField(unique=True)
#     is_staff = models.BooleanField(default=False)

#     class Meta:
#         db_table = 'User'  # exact table name
    # @staticmethod

# def get_or_create_user(phone):
#     return User.objects.get_or_create(username=phone)

from datetime import timedelta
from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class UserToken(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    token = models.CharField(max_length=500)
    created_at = models.DateTimeField(auto_now_add=True)

    def is_expired(self):
        # مثلا اعتبار توکن 7 روز
        return timezone.now() > self.created_at + timedelta(days=7)
    