# from django.shortcuts import render, redirect
# from myapp.models import OTPRecord
# import random
# from django.shortcuts import render
# import sys
# from ..Models import ItemModel, OtpModel
# from django.shortcuts import render
# from ..models import OTPRecord
# from ..Helpers import renderr
# from rest_framework_simplejwt.tokens import RefreshToken

# otp_t = OtpModel.OtpModel

