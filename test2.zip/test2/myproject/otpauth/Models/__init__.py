# from views import user_tt
from django.db import models
class User(models.Model):
    url = models.URLField()
    username = models.CharField(max_length=150, unique=True)
    email = models.EmailField(unique=True)
    is_staff = models.BooleanField(default=False)

    class Meta:
        db_table = 'User'  # exact table name

