# commands assigned to User model

from .models import User

def get_recordByphone(phone):
    result = User.objects.filter(phone_number = phone).latest('expires_at')
    return result
 
def find_Byphone(phone):
        res = User.objects.filter(username=phone).first()
        return res
    
@staticmethod
def get_or_create_user(phone):
    return User.objects.get_or_create(username=phone)

def filter_USerByid(id):
    res = User.objects.filter(id=id).first()
    return res


