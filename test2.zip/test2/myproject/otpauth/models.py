import sys
from django.db import models

# Create your models here.
from django.db import models
from django.utils import timezone
from datetime import timedelta

class OTPRecord(models.Model):
    phone_number = models.CharField(max_length=15)
    otp = models.CharField(max_length=6)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()

    def save(self, *args, **kwargs):
        # Set expiration to 5 minutes from creation
        if not self.expires_at:
            self.expires_at = timezone.now() + timedelta(minutes=5)
        super().save(*args, **kwargs)

    def is_expired(self):
        return timezone.now() > self.expires_at
    def get_otpbyNumber(phone):
        result = otp_t.objects.filter(phone_number=phone).latest('created_at')
        return result


    def createOtp(phone, otp):
        result = otp_t.objects.create(
            phone_number=phone,
            otp=otp,
            expires_at=timezone.now() + timedelta(minutes=5)
        )
        return result


    @staticmethod
    def getRecord_Bynumber(phone):
        result = OTPRecord.objects.filter(phone_number=phone).order_by('expires_at').last()
        return result
    def mintes_Expire5():
        return timezone.now() + timedelta(minutes=5)
    @staticmethod
    def update_OrCreate(phone, otp):
        fiveminutes = timezone.now() + timedelta(minutes=5)
        result = OTPRecord.objects.update_or_create(
            phone_number=phone,
            defaults={
                'otp': otp,
                'expires_at': fiveminutes
            }
        )
        return result
    
otp_t = OTPRecord
# from myapp.views import BaseView
from django.utils import timezone
from datetime import timedelta

# from myapp.models import OTPRecord


# otp_t = BaseView().model('otp')







class User(models.Model):
    url = models.URLField()
    username = models.CharField(max_length=150, unique=True)
    email = models.EmailField(blank=True, null=True, unique=False)
    is_staff = models.BooleanField(default=False)

    class Meta:
        db_table = 'User'  # exact table name



    
# from django.db import models
# from django.contrib.auth.models import User
# from django.utils import timezone

# class UserToken(models.Model):
#     user = models.OneToOneField(User, on_delete=models.CASCADE)
#     token = models.CharField(max_length=500)
#     created_at = models.DateTimeField(auto_now_add=True)

#     def is_expired(self):
#         # مثلا اعتبار توکن 7 روز
#         return timezone.now() > self.created_at + timedelta(days=7)
    