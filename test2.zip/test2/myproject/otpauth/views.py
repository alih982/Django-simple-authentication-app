import sys
from django.shortcuts import render
import random
from django.contrib.auth import get_user_model
from django.shortcuts import render, redirect
from django.views import View
from django.utils import timezone

from django.http import JsonResponse
from django.contrib.auth import get_user_model
from django.conf import settings

from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.authentication import JWTAuthentication
from otpauth.models import OTPRecord
from otpauth import users

# otp table stored in variable otp_tt
otp_tt = OTPRecord
user_tt = users
# creating controller class to be used in myproject/urls.py
class OTPController(View):
    # the first request to otp/ is rendered here
    def get(self, request):
        return render(request, 'otp_page.html', {
            'show_otp_input': False,
            'message': '',
            'phone': ''
        })
    # phone number and otp are submitted here
    def post(self, request):
        # getting post values
        phone = request.POST.get('phone')
        otp_input = request.POST.get('otp')

        if not phone:
            return render(request, 'otp_page.html', {
                'message': 'Phone is required',
                'show_otp_input': False,
                'phone': ''
            })
        # checking otp input
        if otp_input:
            try:
                # method getRecord_Bynumber is from models.py
                record = otp_tt.getRecord_Bynumber(phone)
            except OTPRecord.DoesNotExist:
                return render(request, 'otp_page.html', {
                    'message': '❌ No OTP found',
                    'show_otp_input': True,
                    'phone': phone
                })

            if record.is_expired():
                return render(request, 'otp_page.html', {
                    'message': '❌ OTP expired',
                    'show_otp_input': True,
                    'phone': phone
                })
            # checks if entered otp wasn't correct
            if record.otp != otp_input:
                return render(request, 'otp_page.html', {
                    'message': '❌ Invalid OTP',
                    'show_otp_input': True,
                    'phone': phone
                })


            user = user_tt.find_Byphone(phone)
            if not user:
                users = user_tt.get_or_create_user(phone)
                return users
            print( "ID:", user.id) # checking user id created
            refresh = RefreshToken.for_user(user) 


            response = redirect('panel')
            response.set_cookie(
                key='access_token',
                value=str(refresh.access_token),
                httponly=True,
                secure=False,
                samesite='Lax',
                max_age=300
            )
            response.set_cookie(
                key='refresh_token',
                value=str(refresh),
                httponly=True,
                secure=False,
                samesite='Lax',
                max_age=7 * 24 * 60 * 60
            )
            return response
        # generating otp
        otp = OtpService.generate_otp()
        # if user exists, generates new otp
        otp_tt.update_OrCreate(phone, otp)
        print(f"OTP for {phone}: {otp}")  # Replace with SMS service

        return render(request, 'otp_page.html', {
            'message': f'✅ OTP is {otp}',
            'show_otp_input': True,
            'phone': phone
        })


def panel_view(request):
    access_token = request.COOKIES.get('access_token')
    if not access_token:
        return redirect('otp_page')

    jwt_auth = JWTAuthentication()

    try:
        validated_token = jwt_auth.get_validated_token(access_token)
        user_id = validated_token.get('user_id')
        user = user_tt.filter_USerByid(user_id)

        if not user:
            raise Exception('User not found')

    except Exception as e:
        print(f"User fetch error: {e}")
        return redirect('otp_page')

    return render(request, 'panel.html', {'user': user})


def log_out(request):
    return render(request, 'home.html')



class OtpService():
    @staticmethod
    def generate_otp():
      return str(random.randint(100000, 999999))
    
    def setCookieAndRedirect(name):
      redirect(name).set_cookie(
                key='access_token',
                value=str(redirect(name).access_token),
                httponly=True,
                secure=False,
                samesite='Lax',
                max_age=300
            )
      redirect(name).set_cookie(
                key='refresh_token',
                value=str(redirect(name)),
                httponly=True,
                secure=False,
                samesite='Lax',
                max_age=7 * 24 * 60 * 60
            )
    def refreshh(user):
      return RefreshToken.for_user(user)


